#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/i2c.h"
#include "driverlib/pin_map.h"
#include "inc/hw_gpio.h"




#define I2C_SLAVE_ADDRESS 0x50 // Example slave address
#define GPIO_PB0_I2C0SCL 0x00010803
#define GPIO_PB1_I2C0SDA 0x00010C03

void PortF_Init(void);
void Blue_ON(void);
void Blue_OFF(void);
void Green_ON(void);
void Green_OFF(void);
void Red_ON(void);
void Red_OFF(void);
bool Right_Button(void);
bool Left_Button(void);

void PortF_Init(void) {
    // Enable GPIO Port F
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    // Configure Port F pins for LED and buttons
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);


    // Step 3: Unlock Port F pin 0 (only required for PF0, as it is locked by default)
        HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY;   // Unlock Port F
        HWREG(GPIO_PORTF_BASE + GPIO_O_CR) |= GPIO_PIN_0;       // Commit register for PF0
        HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = 0;               // Re-lock Port F

        // Step 4: Configure pins 0 and 4 as input with pull-up resistors
        GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4);
        GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);
}


void I2CMasterInit(void) {
    // Set the system clock to 50 MHz
    SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);

    // Enable the I2C0 peripheral
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);

    // Enable the GPIO port for I2C0
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);

    // Assuming I2C0 uses PB0 for SCL and PB1 for SDA
    GPIOPinConfigure(GPIO_PB2_I2C0SCL);          // Configure PB0 as I2C0 SCL
    GPIOPinConfigure(GPIO_PB3_I2C0SDA);          // Configure PB1 as I2C0 SDA
    GPIOPinTypeI2CSCL(GPIO_PORTB_BASE, GPIO_PIN_2); // Set PB0 as I2C SCL
    GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_3);    // Set PB1 as I2C SDA

    // Initialize the I2C Master
    I2CMasterInitExpClk(I2C0_BASE, SysCtlClockGet(), false);
}


void I2CMasterSend(uint8_t slaveAddr, uint8_t data) {
    // Set the I2C master to transmit mode
    I2CMasterSlaveAddrSet(I2C0_BASE, slaveAddr, false);

    // Send the data
    I2CMasterDataPut(I2C0_BASE, data);

    // Send the data to the slave
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_SINGLE_SEND);

    // Wait for the transmission to complete
    while (I2CMasterBusy(I2C0_BASE));
}


uint8_t I2C_Read(void) {
    uint8_t receivedData;

    // Set the slave address and indicate a read operation
    I2CMasterSlaveAddrSet(I2C1_BASE, I2C_SLAVE_ADDRESS, true);

    // Send the start condition and receive data
    I2CMasterControl(I2C1_BASE, I2C_MASTER_CMD_SINGLE_RECEIVE);

    // Wait until the transfer is complete
    while (I2CMasterBusy(I2C1_BASE)) {}

    // Get the received data
    receivedData = I2CMasterDataGet(I2C1_BASE);

    return receivedData;
}

int main(void) {
    I2CMasterInit();
    PortF_Init();
    int counter = 0;


    while (1) {

        if(Right_Button()==1 && Left_Button()==0)
                        {

                            while(Right_Button()==1 && Left_Button()==0){}
                            counter++;
                            if(counter>3)
                            {
                                counter=0;
                            }
                        }

                        else if(Left_Button()==1 && Right_Button()==0)
                        {
                            while(Left_Button()==1 && Right_Button()==0){}
                            counter--;
                            //counter++;
                            if(counter<-3)
                            {
                                counter=0;
                            }
                        }

                        else if(Left_Button()==1 && Right_Button()==1)
                        {
                            while(Left_Button()==1 || Right_Button()==1){Blue_ON();   Green_ON();   Red_ON();}
                            counter=0;
                        }



                switch(counter)
                {
                    case 0:         counter = 0x00;
                         break;

                    case 1:         counter = 0x01;
                        break;

                    case 2:         counter = 0x02;
                        break;

                    case 3:         counter = 0x03;
                        break;

                    case -1:        counter = 0x04;
                        break;

                    case -2:        counter = 0x05;
                        break;

                    case -3:        counter = 0x06;
                        break;
                }
        // Send data to the slave
        I2CMasterSend(I2C_SLAVE_ADDRESS, counter);

    }
}

// LED control functions
void Blue_ON(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, GPIO_PIN_2); }
void Blue_OFF(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, 0); }
void Green_ON(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, GPIO_PIN_3); }
void Green_OFF(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0); }
void Red_ON(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, GPIO_PIN_1); }
void Red_OFF(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0); }

// Button check functions
bool Right_Button(void) { return GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_0) == 0; }
bool Left_Button(void) { return GPIOPinRead(GPIO_PORTF_BASE, GPIO_PIN_4) == 0; }
