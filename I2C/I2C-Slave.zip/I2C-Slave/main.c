#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/i2c.h"
#include "driverlib/pin_map.h"
#include "inc/hw_gpio.h"

void PortF_Init(void);
void Blue_ON(void);
void Blue_OFF(void);
void Green_ON(void);
void Green_OFF(void);
void Red_ON(void);
void Red_OFF(void);

#define GPIO_PB0_I2C0SCL 0x00010803
#define GPIO_PB1_I2C0SDA 0x00010C03
#define I2C_SLAVE_ADDRESS 0x50 // Example slave address

void PortF_Init(void) {
    // Enable GPIO Port F
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    // Configure Port F pins for LED and buttons
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE, GPIO_PIN_1 | GPIO_PIN_2 | GPIO_PIN_3);


    // Step 3: Unlock Port F pin 0 (only required for PF0, as it is locked by default)
        HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = GPIO_LOCK_KEY;   // Unlock Port F
        HWREG(GPIO_PORTF_BASE + GPIO_O_CR) |= GPIO_PIN_0;       // Commit register for PF0
        HWREG(GPIO_PORTF_BASE + GPIO_O_LOCK) = 0;               // Re-lock Port F

        // Step 4: Configure pins 0 and 4 as input with pull-up resistors
        GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4);
        GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_0 | GPIO_PIN_4, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);


}

void I2C0SlaveInit(void) {
    // Set the system clock to 50 MHz
    SysCtlClockSet(SYSCTL_SYSDIV_4 | SYSCTL_USE_PLL | SYSCTL_OSC_MAIN | SYSCTL_XTAL_16MHZ);


    // Enable the I2C0 peripheral
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);

    // Enable the GPIO port for I2C0
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);

    // Assuming I2C0 uses PB0 for SCL and PB1 for SDA
    GPIOPinConfigure(GPIO_PB2_I2C0SCL);          // Configure PB0 as I2C0 SCL
    GPIOPinConfigure(GPIO_PB3_I2C0SDA);          // Configure PB1 as I2C0 SDA
    GPIOPinTypeI2CSCL(GPIO_PORTB_BASE, GPIO_PIN_2); // Set PB0 as I2C SCL
    GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_3);    // Set PB1 as I2C SDA

    // Initialize the I2C Slave with the specified address
    I2CSlaveInit(I2C0_BASE , I2C_SLAVE_ADDRESS);
    I2CSlaveEnable(I2C0_BASE);

    // Set the slave address (0x50 in this case)
   // I2CSlaveAddressSet(I2C0_BASE, 0x50); // Set the slave address to 0x50
}
void I2CSlaveHandler(void) {
    uint32_t status;
    uint8_t data;

    // Get the status of the I2C slave
    status = I2CSlaveStatus(I2C0_BASE);

    if (status & I2C_SLAVE_ACT_RREQ) {
        // Master is sending data to the slave
        data = I2CSlaveDataGet(I2C0_BASE); // Read data sent from master

        switch(data)
                        {
                            case 0:     Blue_ON();   Green_ON();    Red_ON();
                                 break;

                            case 1:     Blue_OFF();   Green_OFF();  Red_ON();
                                break;

                            case 2:     Blue_OFF();   Green_ON();   Red_OFF();
                                break;

                            case 3:     Blue_ON();   Green_OFF();   Red_OFF();
                                break;

                            case -1:        Blue_ON();   Green_OFF();   Red_OFF();
                                break;

                            case -2:        Blue_OFF();   Green_ON();   Red_OFF();
                                break;

                            case -3:            Blue_OFF();   Green_OFF();  Red_ON();
                                break;
                        }

        // Process received data (e.g., store, respond, etc.)
    }
    else if (status & I2C_SLAVE_ACT_TREQ) {
        // Master requests data from the slave
        I2CSlaveDataPut(I2C0_BASE, 0x55); // Send example data (0x55) to the master
    }
}

int main(void) {
    I2C0SlaveInit();
    PortF_Init();

    while (1) {
        // Handle I2C communication in the slave
        I2CSlaveHandler();
    }
}

// LED control functions
void Blue_ON(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, GPIO_PIN_2); }
void Blue_OFF(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_2, 0); }
void Green_ON(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, GPIO_PIN_3); }
void Green_OFF(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_3, 0); }
void Red_ON(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, GPIO_PIN_1); }
void Red_OFF(void) { GPIOPinWrite(GPIO_PORTF_BASE, GPIO_PIN_1, 0); }
