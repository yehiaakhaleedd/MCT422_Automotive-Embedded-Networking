/*
 * main.c
 *
 *  Created on: 22 Nov 2024
 *      Author: Team: 4
 *      purpose: The purpose of this main file is to implement a simple embedded application where button presses control the state of a system,
 *      and the system responds by changing its behavior (e.g., incrementing or decrementing a counter and controlling LEDs).
 */


/***********************************************
 * Includes
 ***********************************************/
#include <APP/scheduler.h>
#include <HAL/initialization.h>





/***********************************************
 * Function Name: main
 * Inputs: N/A
 * Outputs: N/A
 * Reentrancy: Non-Reentrant
 * Synchronous: Synch
 * Description: The main function initializes the system by calling the necessary
 *              initialization functions for the MCAL (Microcontroller Abstraction
 *              Layer), buttons, and LEDs. It enters an infinite loop to keep the
 *              program running, allowing the system to continuously perform tasks
 *              based on the initialization and interrupt handlers.
 ***********************************************/
int main(void)
{
    //SPI_masterSend(0x09);
    INITIALIZATION_MCAL();
    INITIALIZATION_buttons();
    INITIALIZATION_leds();

    while(1) {


        sw1 = (bool)BUTTONS_rightButton();
        sw2 = (bool)BUTTONS_leftButton();

        if (sw1 == true && last_sw1_state == false && sw2 == true && last_sw2_state == false) {
            counter = STATE_INIT;

            /*SPI_masterSend(0x09);
            counter = 0;*/
        }

        else if (sw1 == true && last_sw1_state == false) {


            if(sw1 == 1 && last_sw1_state == 0 && g_ui32SysTickCount >= 60)
            {
                holdButtonFlag = true;
                LED_greenOn();
            }

            counter++;
            if (counter > 3) {
                counter = STATE_RED;
            }
        }

        else if (sw2 == true && last_sw2_state == false) {
            while ((bool)BUTTONS_leftButton() == true && (bool)BUTTONS_rightButton() == false) {} // Avoid integer/boolean mismatch
            counter--;
            if (counter < 1) {
                counter = STATE_BLUE;
            }
        }


        last_sw1_state = sw1;
        last_sw2_state = sw2;

        if(sw1 == 0)
        {
            g_ui32SysTickCount = 0;
            holdButtonFlag = false;
        }

        APP_stateControl(counter);
        APP_uartControl();

        if(counter == COMM_LOST)
        {
            LED_redBlink();
        }

    }

}




